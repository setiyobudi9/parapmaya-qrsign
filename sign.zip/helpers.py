#import csv
#import datetime
#import pytz
#import requests
#import subprocess
#import urllib
#import uuid
import hashlib

from flask import redirect, render_template, session
from functools import wraps


def apology(message, code=400):
    """Render message as an apology to user."""

    def escape(s):
        """
        Escape special characters.

        https://github.com/jacebrowning/memegen#special-characters
        """
        for old, new in [
            ("-", "--"),
            (" ", "-"),
            ("_", "__"),
            ("?", "~q"),
            ("%", "~p"),
            ("#", "~h"),
            ("/", "~s"),
            ('"', "''"),
        ]:
            s = s.replace(old, new)
        return s

    return render_template("apology.html", top=code, bottom=escape(message)), code


def login_required(f):
    """
    Decorate routes to require login.

    http://flask.pocoo.org/docs/0.12/patterns/viewdecorators/
    """

    @wraps(f)
    def decorated_function(*args, **kwargs):
        if session.get("user_id") is None:
            return redirect("/login")
        return f(*args, **kwargs)

    return decorated_function


# Function to convert document properties input to random unic's number

def generate_number(input_text):
    # Hash the combined string using SHA-256
    hashed_str = hashlib.sha256(input_text.encode()).hexdigest()

    # Convert the hashed string to an integer
    num = int(hashed_str, 16)

    # Define the desired length of the number
    desired_length = 20

    # Trim or pad the number to the desired length
    tek_num = str(num)[:desired_length].zfill(desired_length)

    return int(tek_num)
