'''
Final Project CS50x For Teacher Indonesia 2023 - 2024
QR Sign Generator and Validation / Setiyo Budi

template form : https://cs50.harvard.edu/indonesia/2024/psets/9/finance/
https://cs50.harvard.edu/indonesia/2024/psets/9/finance/
'''

import os
from datetime import datetime

from cs50 import SQL
from flask import Flask, flash, redirect, render_template, request, session, send_file
from flask_session import Session
from werkzeug.security import check_password_hash, generate_password_hash

from helpers import apology, login_required, generate_number
import qrcode

# Configure application
app = Flask(__name__)


# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///sign.db")


@app.after_request
def after_request(response):
    """Ensure responses aren't cached"""
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response


@app.route("/")
# @login_required
def index():
    """chek document validation, without login"""

    return render_template("index.html")


# Function to chek validation number (generated randomly to QR Code)

@app.route('/valids')
def valids():
    url = request.args.get('url')
    valids = db.execute("SELECT * FROM dokumen WHERE tek2num = ?", url)
    if not valids:
        return apology("NOT VALID DOCUMENT")
    return render_template('index.html', valids=valids)


# Function to show all entryed document properties

@app.route("/list")
@login_required
def list():
    """Show Documents List"""

    # Fetch documents list form dokumen db
    doc_lists = db.execute("SELECT * FROM dokumen WHERE user_id = ?",
                           session["user_id"])

    # Fetch user name from user db
    user_info = db.execute("SELECT * FROM users WHERE id = ?",
                           session["user_id"])

    # Extract username and option from user_info
    user_name = user_info[0]["username"] if user_info else None
    user_opt = user_info[0]["option"] if user_info else None

    return render_template("list.html", doc_lists=doc_lists, user_opt=user_opt)


# Function to input document properties (ID, date, department, resume)

@app.route("/input", methods=["GET", "POST"])
@login_required
def input():
    """Input document properties by administrator"""
    if request.method == "GET":
        return render_template("input.html")

    else:
        # Get document id, date, department and resume from the form
        docid = request.form.get("docid")
        tanggal = request.form.get("tanggal")
        depart = request.form.get("depart")
        docdesc = request.form.get("docdesc")

        # Check if inputs are valid
        if not docid or not tanggal or not depart or not docdesc:
            return apology("it must not be empety")

        # Get active user ID  from session
        user_id = session.get("user_id")

        # Insert properties to dokumen db
        db.execute("INSERT INTO dokumen(user_id, docid, tanggal, depart, docdesc, doc_date) VALUES (?, ?, ?, ?, ?, ?)",
                   user_id, docid, tanggal, depart, docdesc, datetime.now())

        # Flash success message and redirect to homepage
        flash(f"Congrulation, you have finish document properties", "success")
        return redirect("/list")


# Login Function

@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""

    # Forget any user_id
    session.clear()

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 403)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 403)

        # Query database for username
        user = db.execute("SELECT * FROM users WHERE username = ?", request.form.get("username"))

        # Ensure username exists and password is correct
        if len(user) != 1 or not check_password_hash(user[0]["hash"], request.form.get("password")):
            return apology("invalid username and/or password", 403)

        # Remember which user has logged in
        session["user_id"] = user[0]["id"]
        session["username"] = user[0]["username"]

        # Redirect user to document list
        return redirect("/list")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")


@app.route("/logout")
def logout():
    """Log user out"""

    # Forget any user_id
    session.clear()

    # Redirect user to index
    return redirect("/")


# Function to register new user

@app.route("/register", methods=["GET", "POST"])
def register():
    """Register user"""
    # Display registration form
    if request.method == "GET":
        return render_template("register.html")
    else:
        # Access form data
        username = request.form.get("username")
        password = request.form.get("password")
        option = request.form.get("option")
        confirmation = request.form.get("confirmation")

        # Validate user registration data (user name / password)
        if not username:
            return apology("Username is not available")
        # Ensure username is not alredy registered
        elif len(db.execute("SELECT username FROM users WHERE username = ?", username)):
            return apology("username already in use", 400)
        # chek password properties
        elif not password:
            return apology("MISSING PASSWORD")
        # strong password feature
        # elif check_password(password) == False:
            # return apology("PASSWORD IS NOT VALID")
        elif not confirmation or (password != confirmation):
            return apology("PASSWORDS DON'T MATCH")

        # Using pbkdf2:sha256 hash algoritm to generate hash
        pass_hash = generate_password_hash(password, method="pbkdf2:sha256", salt_length=4)

        # Add user, hashed password and option to users db
        result = db.execute("INSERT INTO users(username, hash, option) VALUES (?, ?, ?)",
                            username, pass_hash, option)

        if result:
            # Redirect to the login page
            flash("Congratulation, you have Registered", "success")
            return redirect("/login")


# Query for approve request

@app.route("/approval", methods=["GET", "POST"])
@login_required
def approval():
    """Approve the document sign request"""

    # user_id = session.get("user_id")

    # Fetch documents list form dokumen db, show just un approve document
    dproprs = db.execute("SELECT * FROM dokumen WHERE user_id = ? AND status = 'dibaca'",
                         session["user_id"])

    if request.method == "GET":
        return render_template("approve.html", dproprs=dproprs)

    elif request.method == "POST":
        # user_id = session.get("user_id")
        apprs = request.form.get("appr")
        if apprs:
            # get text input from dokumen db, last entry, 3 category (no surat, tanggal, and official)

            # docid = apprs[-1]["docid"]
            tanggal = dproprs[-1]["tanggal"]
            depart = dproprs[-1]["depart"]
            docdesc = dproprs[-1]["docdesc"]

            comb_text = "".join([docdesc, tanggal, depart])
            # generate text to 20 digit unic number
            tek2num = format(generate_number(comb_text), '020d')
            # update dokumen db, change status dibaca > diterima, and generated unic number
            db.execute("UPDATE dokumen SET tek2num = ?, status = 'DITERIMA' WHERE id = ?", tek2num, apprs)

            # Redirect to document list
            return redirect("/list")
        else:
            return redirect("/list")


# Function to generate qr code sign
@app.route('/qrsign', methods=['GET', 'POST'])
@login_required
def qrsign():

    user_id = session.get("user_id")

    if request.method == "GET":
        # Get the list of dokument approved (status = DITERIMA) from dokumen db
        datas = db.execute("SELECT tek2num, docid, status FROM dokumen WHERE status = 'DITERIMA' AND user_id = ?", user_id)
        # Display the sell form for GET requests, passing available symbols to template
        return render_template("qrsign.html", datas=datas)

    else:
        # Join generated number (validation number) with url to chek validation
        dataval = request.form.get("data")
        # Prevent null
        if not dataval:
            return redirect("/qrsign")

        hal = ["https://urban-space-barnacle-6vvjrxv59rj24p4x-5000.app.github.dev/valids?url=", dataval]
        data = "".join(hal)
        qr = qrcode.make(data)
        qr.save('static/qrsign.png')
        return render_template('qrsign.html', data=data)


# Function to download qr code sign
@app.route('/download')
def download():
    return send_file('static/qrsign.png', as_attachment=True)
