# QR Sign Generator and Validator
## Intro
- Bulit
-


```sh
cd dillinger
npm i
node app
```

## li
List of

| Plugin | README |
| ------ | ------ |
| Dropbox |   |
|asdfas|asda|

### jhgjhsd

hal ini
